
import java.util.*;
import java.time.LocalDate;

public class Transactions {
	public Transactions(int transactionId, LocalDate transactionDate, String transactionType,
			double transactionAmount) {
		super();
		this.transactionId = transactionId;
		this.transactionDate = transactionDate;
		this.transactionType = transactionType;
		this.transactionAmount = transactionAmount;
	}
	public Transactions(Account account) {
		super();
		this.account = account;
	}
	private int transactionId;
	private LocalDate transactionDate;
	
	private String transactionType;
	private double transactionAmount;
	private Account account;
	//private Transactions[] transactionSummary;
	private int transCount;
	public Transactions(){
		
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public LocalDate getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(LocalDate transactionDate) {
		this.transactionDate = transactionDate;
	}
	public double getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	
	
	public int get2AccountNo()
	{
		return account.getAccountNo();
		
	}
	public double get2AccountBalance()
	{
		return account.getOpeningBalance();
		
	}
	public int getTransCount()
	{
		return this.transCount;
	}
	public void setTransCount(int transCount)
	{
		this.transCount=transCount;
		
	}
	@Override
	public String toString() {
		return "Transactions [transactionId=" + transactionId + ", transactionDate=" + transactionDate
				+ ", transactionType=" + transactionType + ", transactionAmount=" + transactionAmount + ", account="
				+ account + "]";
	}


}
