
import java.util.ArrayList;
import java.util.Arrays;

public class Customer {
 private long customerId;
 private String customerName;
 private Address address;
 private ArrayList<Account> account=new ArrayList<>();;
 
public Customer(long customerId, String customerName, Address address, String mobileNo, String emailId) {
	super();
	this.customerId = customerId;
	this.customerName = customerName;
	this.address = address;
	this.mobileNo = mobileNo;
	this.emailId = emailId;
}


private String mobileNo;
 private String emailId;
 private int accountNo;
 private int accountCount;

 public Customer()
 {
	 
 }
 public Customer(int customerId, String customerName, Address address, String mobileNo,
			String emailId) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.address = address;
		this.account = account;
		this.mobileNo = mobileNo;
		this.emailId = emailId;
	}
 
public Customer(ArrayList<Account> account) {
	super();
	this.account = account;
}
public long getCustomerId() {
	return customerId;
}
public Customer(int accountCount) {
	super();
	this.accountCount = accountCount;
}
public void setCustomerId(long customerId) {
	this.customerId = customerId;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public Address getAddress() {
	return address;
}
public void setAddress(Address address) {
	this.address = address;
}
public  ArrayList<Account> getAccount() {
	return account;
}
public void setAccount(ArrayList<Account> account) {
	this.account = account;
}
public String getMobileNo() {
	return mobileNo;
}
public void setMobileNo(String mobileNo) {
	this.mobileNo = mobileNo;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
public int getAccountCount()
{
	return this.accountCount;
}
public void setAccountCount(int accountCount)
{
	this.accountCount=accountCount;
	
}
public int get1AccountNo(int accountCount)
{
	return account.get(accountCount).getAccountNo();
	
}







 
}
