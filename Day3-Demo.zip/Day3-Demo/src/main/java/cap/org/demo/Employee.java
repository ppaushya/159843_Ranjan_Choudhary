package cap.org.demo;

import java.util.Scanner;

public class Employee {
	
	int empId;
	String fName,lName;
	int age;
	double salary;
	
	public void getEmployeeDetails() {
		
		Scanner s=new Scanner(System.in);
		System.out.println("Enter Employee Details" );
		empId=s.nextInt();
		fName=s.next();
		lName=s.next();
		age=s.nextInt();
		salary=s.nextDouble();
		//s.close();
	}
	public void showEmp() {
		System.out.println("Employee ID: "+ empId);
		System.out.println("Employee First Name: "+ fName);
		System.out.println("Employee Last Name: "+ lName);
		System.out.println("Employee Age: "+ age);
		System.out.println("Employee Salary: "+ salary);
	}
	public void sortEmp(Employee[] emp,int a) {
		 Employee temp;
		for (int i=0;i<a;i++) {
			for(int j=0;j<a;j++) {
				if(emp[i].empId<emp[j].empId) {
					temp=emp[i];
					emp[i]=emp[j];
					emp[j]=temp;
				}		
			}		
		}
	}

	public static void main(String[] args) {
		int a=0;
		
		Scanner s=new Scanner(System.in);
		Employee emp=new Employee();
		System.out.println("Enter no. of employees");
		a=s.nextInt();
		//s.close();
		Employee[] e=new Employee[a];
		for(int i=0;i<a;i++) {
			e[i]=new Employee();
			e[i].getEmployeeDetails();
			//e[i].showEmp();
			
		}
		emp.sortEmp(e,a);
		for(int i=0;i<a;i++) {
			e[i].showEmp();
			
		}

	}

}
