package cap.org.demo;

import java.util.Scanner;

public class DDAFunc2 {
	
	
	public void sumArr(int[][] a1,int r1,int c1,int[][] a2,int r2,int c2) {
		if((r1==r2)&&(c1==c2)) {
			for(int i=0;i<r1;i++) {
				for (int j=0;j<c1;j++) {
					System.out.print(a1[r1][c1]+a2[r2][c2]);
				}
				System.out.println();
			}
		}
		else System.out.println("Error");
	}
	/*public void showArray(int[][] arr,int r,int c) {
		for(int i=0;i<r;i++) {
			for(int j=0;j<c;j++) {
				System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		}
	}
	
	public void findSmallestElement(int[][] arr,int r,int c) {
		int temp,ele=0,flag=0;
		for(int m=0;m<r;m++) {
		for (int i=0;i<c;i++) {
			for(int j=0;j<c;j++) {
				if(arr[m][i]<arr[m][j]) {
					temp=arr[m][i];
					arr[m][i]=arr[m][j];
					arr[m][j]=temp;
				}		
			}
		}
		}
		for(int i=0;i<r;i++) {
			for(int j=0;j<c-1;j++) {
				if(arr[i][j+1]-arr[i][j]!=1) {
					ele=arr[i][j]+1;
					break;
				}
				else if(arr[i][j+1]-arr[i][j]==1) {
					flag++;
				}
			}
			if (flag==c-1) {
				ele=arr[i][c-1]+1;
			System.out.println(ele+ " ");}
			ele=0;
		}
		
		//System.out.println(ele+ " ");
		//ele=0;
	}
	
	public  void lowSum(int[][] arr, int r,int c) {
		int sum=0,low=0,x=0;
		for(int i=0;i<r;i++) {
			for(int j=0;j<c;j++) {
				sum=sum+arr[i][j];
			}
			if(i==0)
				low=sum;
			if(low>sum) {
				low=sum;
				x=i;
			}
			sum=0;
		}
		for(int j=0;j<c;j++)
			System.out.print(arr[x][j]+" ");
	}*/

	public static void main(String[] args) {
		int[][] arr;
		int r,c,r1,r2,c1,c2;
		DDAFunc2 obj=new DDAFunc2();
		Scanner s=new Scanner(System.in);
		/*System.out.println("Enter the number of rows");
		r=s.nextInt();
		System.out.println("Enter the number of column");
		c=s.nextInt();
		arr=new int[r][c];
		System.out.println("Enter Array Elements");
		for(int i=0;i<r;i++) {
			for(int j=0;j<c;j++) {
				arr[i][j]=s.nextInt();
			}
		}*/
		System.out.println("Enter the number of rows for 1st Array");
		r1=s.nextInt();
		System.out.println("Enter the number of column for 1st Array");
		c1=s.nextInt();
		System.out.println("Enter the number of rows for 2nd Array");
		r2=s.nextInt();
		System.out.println("Enter the number of column for 2nd Array");
		c2=s.nextInt();
		int[][] arr1=new int[r1][c1];
		int[][] arr2=new int[r2][c2];
		//obj.lowSum(arr,r,c);
		//obj.findSmallestElement(arr,r,c);
		obj.sumArr(arr1,r1,c1,arr2,r2,c2);
		//obj.showArray(arr,r,c);

	}

}
