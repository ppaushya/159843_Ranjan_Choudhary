package cap.org.demo;

import java.util.Scanner;

public class DemoArray {
	
	int[] myArr;
	
	public void getArrayElements(int size) {
		Scanner s=new Scanner(System.in);
		myArr=new int[size];
		System.out.println("Enter "+size+" Arrray Elements");
		for(int i=0;i<size;i++)
			myArr[i]=s.nextInt();
		
	}
	
	public void printArr() {
		for(int i=0;i<myArr.length;i++)
			System.out.println(myArr[i]);
	}
	
	public void reverseArr(int[] arr,int size) {
		int[] revArr= new int[size];
		for(int i=0,j=size-1;i<size;i++,j--) {
			revArr[i]=arr[j];
			}
		for(int i=0,j=size-1;i<size;i++,j--) {
			arr[i]=revArr[j];
		}
	}
	
	public void bubbleSort() {
		int temp;
		for (int i=0;i<myArr.length;i++) {
			for(int j=0;j<myArr.length;j++) {
				if(myArr[i]<myArr[j]) {
					temp=myArr[i];
					myArr[i]=myArr[j];
					myArr[j]=temp;
				}
					
			}
			
				
		}
		
	}
	
	public void bigEle() {
		int big=myArr[0];
		for(int i=0;i<myArr.length;i++) {
			
				if(myArr[i]>big)
					big=myArr[i];
			
		}
		System.out.println("Biggest Element: "+ big);
	}
	
	public void evenArr() {
		int sum=0;
		System.out.println("Even Elements of Array are");
		for (int i=0;i<myArr.length;i++) {
			if(myArr[i]%2==0) {
				System.out.print(myArr[i]+" ");
				sum=sum+myArr[i];
			}
		}
		System.out.println("Sum of Even Elements "+ sum);
		
	}
	
	public void smallEle() {
		int small=myArr[0];
		for(int i=0;i<myArr.length;i++) {
			
				if(myArr[i]<small)
					small=myArr[i];
			
		}
		System.out.println("Smallest Element: "+ small);
	}
	
	public int findSmallestElement(int[] arr) {
		int temp,ele=0,flag=0;
		for (int i=0;i<arr.length;i++) {
			for(int j=0;j<arr.length;j++) {
				if(arr[i]<arr[j]) {
					temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}		
			}
		}
		for(int i=0;i<arr.length-1;i++) {
			//for(int j=0;j<arr.length;j++) {
				if(arr[i+1]-arr[i]!=1) {
					ele=arr[i]+1;
					break;
				}
				else if(arr[i+1]-arr[i]==1) {
					flag++;
				}
			//}
		}
		if (flag==arr.length-1)
			ele=arr[arr.length-1]+1;
		return (ele);
	}

	public static void main(String[] args) {
		int a=0;
		
		Scanner s=new Scanner(System.in);
		DemoArray obj=new DemoArray();
		//System.out.println(obj.myArr);
		System.out.println("enter no. Array Elements");
		a=s.nextInt();
		int[] arr= new int[a];
		//obj.getArrayElements(a);
		//obj.bubbleSort();
		//obj.printArr();
		//obj.bigEle();
		//obj.smallEle();
		//obj.evenArr();
		System.out.println("enter Array Elements");
		for(int i=0;i<a;i++) {
		arr[i]=s.nextInt();}
		int b =obj.findSmallestElement(arr);
		System.out.println(b);

	}

}
