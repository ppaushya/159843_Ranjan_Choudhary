package cap.org.demo;

public class Test {
	
	public void printData(int...arr) {
		for(int value: arr)
			System.out.println(value);
	}

	public static void main(String[] args) {
		int[] num1= {1,2,3,4,5};
		Test obj=new Test();
		obj.printData(num1);

	}

}
