package cap.org.demo;

import java.util.Scanner;

public class DDArray {
	
	

	public static void main(String[] args) {
		int[][] arr;
		arr=new int[3][2];
		Scanner s=new Scanner(System.in);
		/*arr[0][0]=12;
		arr[0][1]=34;
		
		arr[1][0]=90;
		arr[1][1]=9;*/
		System.out.println("Enter the array elements");
		for(int i=0;i<3;i++) {
			for(int j=0;j<2;j++) {
				arr[i][j]=s.nextInt();
			}
		}
		for(int i=0;i<3;i++) {
			for(int j=0;j<2;j++) {
				System.out.print(arr[i][j]);
			}
			System.out.println();
		}
				

	}

}
