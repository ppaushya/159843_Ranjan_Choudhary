package cap.org.demo;

import java.util.Scanner;

public class DDAFunc {
	int size;
	
	public void upperT(int[][] a) {
		for(int i=0;i<size;i++) {
			for(int j=0;j<size;j++) {
				if(i<=j) {
					System.out.print(a[i][j]+" ");
				}
				else System.out.print("  ");
			}
			System.out.println();
		}
	}
	public void lowerT(int[][] a) {
		for(int i=0;i<size;i++) {
			for(int j=0;j<size;j++) {
				if(i>=j) {
					System.out.print(a[i][j]+" ");
				}
				//else System.out.print("  ");
			}
			System.out.println();
		}
	}
	public void transpose(int[][] a) {
		for(int i=0;i<size;i++) {
			for(int j=0;j<size;j++) {
				System.out.print(a[j][i]+" ");
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		int[][] arr;
		DDAFunc obj=new DDAFunc();
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the Degree of Square Matrix");
		obj.size=s.nextInt();
		arr=new int[obj.size][obj.size];
		System.out.println("Enter Array Elements");
		for(int i=0;i<obj.size;i++) {
			for(int j=0;j<obj.size;j++) {
				arr[i][j]=s.nextInt();
			}
		}
		obj.upperT(arr);
		obj.lowerT(arr);
		obj.transpose(arr);

	}

}
