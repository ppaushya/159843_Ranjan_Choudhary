package cap.org.demo;

import java.util.Scanner;

public class StrArray {
	
	String[] myStr;
	public void acceptString(int size) {
		Scanner s =new Scanner(System.in);
		myStr=new String[size];
		System.out.println("Enter "+size+" Elements" );
		for(int i=0;i<size;i++) {
			myStr[i]=s.nextLine();
		}
				
	}
	
	public void printString() {
		for(int i=0;i<myStr.length;i++)
			System.out.println(myStr[i] );
	}
	public void sortStr() {
		String temp;
		for (int i=0;i<myStr.length;i++) {
			for(int j=0;j<myStr.length;j++) {
				if(myStr[i].compareTo(myStr[j])<1) {
					temp=myStr[i];
					myStr[i]=myStr[j];
					myStr[j]=temp;
				}		
			}		
		}
		for (int i=0;i<myStr.length;i++)
			System.out.println(myStr[i] );
	}

	public static void main(String[] args) {
		StrArray obj=new StrArray();
		obj.acceptString(5);
		//obj.printString();
		obj.sortStr();

	}

}
