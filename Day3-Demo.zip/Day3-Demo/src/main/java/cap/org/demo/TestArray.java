package cap.org.demo;

public class TestArray {
	
	public static void main(String[] args) {
		
		int num[]=new int[10];
		int arr[]= {1,2,3,4,6};
		System.out.println(arr.length);
		double pi=3.14;
		short mynum=90;
		num[0]=1;
		num[1]=(int)pi;
		num[2]=45;
		num[3]=mynum;
		num[7]=78;
		System.out.println(num);
		
		for(int i=0;i<10;i++)
			System.out.println(num[i]);
	}

}
