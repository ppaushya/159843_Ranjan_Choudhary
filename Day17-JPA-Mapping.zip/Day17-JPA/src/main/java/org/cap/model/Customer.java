package org.cap.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Customer {
	
	
	@Id
	private CustomerCompositeKey custCompositeKey;
	private String fName;
	private String lName;
	
	public Customer() {
		
	}
	
	public CustomerCompositeKey getCustCompositeKey() {
		return custCompositeKey;
	}
	public void setCustCompositeKey(CustomerCompositeKey custCompositeKey) {
		this.custCompositeKey = custCompositeKey;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	@Override
	public String toString() {
		return "Customer [custCompositeKey=" + custCompositeKey + ", fName=" + fName + ", lName=" + lName + "]";
	}
	public Customer(CustomerCompositeKey custCompositeKey, String fName, String lName) {
		super();
		this.custCompositeKey = custCompositeKey;
		this.fName = fName;
		this.lName = lName;
	}
	
	

}
