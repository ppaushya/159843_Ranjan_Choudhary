package org.cap.onetomany;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity 
public class Employeem {
	
	@Id
	private int empId;
	private String empName;
	
	private Companym company;
	
	public Employeem() {
		
	}

	public Employeem(int empId, String empName, Companym company) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.company = company;
	}
	
	
	

}
