package org.cap.onetomany;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Companym {
	
	@Id
	private int companyId;
	private String companyName;
	
	public Companym() {
		
	}
	
	
	
	

}
