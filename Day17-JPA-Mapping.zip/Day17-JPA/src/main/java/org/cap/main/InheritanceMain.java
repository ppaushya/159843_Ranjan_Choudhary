package org.cap.main;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.cap.model.Module;
import org.cap.model.Project;
import org.cap.model.Task;

public class InheritanceMain {

	public static void main(String[] args) {


EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager entityManager=emf.createEntityManager();
		
		EntityTransaction transaction=entityManager.getTransaction();
		
		transaction.begin();
		
		Project project=new Project(1001, "CapGBanking");
		
		Module module=new Module();
		module.setProjectId(1002);
		module.setProjectName("Wallet App");
		module.setModuleName("Login Module");
		
		Task task=new Task();
		task.setProjectId(1003);
		task.setProjectName("Citi Bank");
		task.setModuleName("Validation Forms");
		task.setTaskName("JavaScript Validation");
		
		entityManager.persist(project);
		entityManager.persist(module);
		entityManager.persist(task);
		
		transaction.commit();

	}

}
