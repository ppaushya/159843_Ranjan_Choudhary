package org.cap.mapping;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class AddressM {
	
	@Id
	private int addressId;
	private String addressLine;
	
	@OneToOne
	@JoinColumn(name="cust_fk")
	private CustomerM customer;
	
	
	public CustomerM getCustomer() {
		return customer;
	}

	public void setCustomer(CustomerM customer) {
		this.customer = customer;
	}

	public AddressM() {
		
		
	}
	
	public AddressM(int addressId, String addressLine) {
		super();
		this.addressId = addressId;
		this.addressLine = addressLine;
		
		
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getAddressLine() {
		return addressLine;
	}

	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}

	@Override
	public String toString() {
		return "AddressM [addressId=" + addressId + ", addressLine=" + addressLine + "]";
	}
	
	

}
