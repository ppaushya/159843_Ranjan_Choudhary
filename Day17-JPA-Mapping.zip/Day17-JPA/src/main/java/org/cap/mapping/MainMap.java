package org.cap.mapping;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainMap {

	public static void main(String[] args) {


EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager entityManager=emf.createEntityManager();
		
		EntityTransaction transaction=entityManager.getTransaction();
		
		transaction.begin();
		
		AddressM address=new AddressM(1001,"19/A, Fourth Avenue");
		
		CustomerM customer=new CustomerM(101, "Tom");
		
		address.setCustomer(customer);
		entityManager.persist(address);
		entityManager.persist(customer);
		
		transaction.commit();
		

	}

}
