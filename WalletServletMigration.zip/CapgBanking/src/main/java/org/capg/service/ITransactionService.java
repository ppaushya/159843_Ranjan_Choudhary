package org.capg.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.Transaction;

public interface ITransactionService {

public void createTransaction(Transaction transaction);
	
	//public List<Transaction> getAllTransactions(Customer customer,LocalDate fromdate,LocalDate todate);
public List<Transaction> getAllTransactions(Customer customer);
	
}
