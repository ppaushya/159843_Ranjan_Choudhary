package org.capg.controller;

import java.io.IOException;

import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Customer;
import org.capg.model.Transaction;
import org.capg.service.AccountServiceImpl;
import org.capg.service.IAccountService;
import org.capg.service.ITransactionService;
import org.capg.service.TransactionServiceImpl;


@WebServlet("/SummaryTransaction")
public class SummaryTransaction extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		HttpSession session=request.getSession();
		int custId=(int) session.getAttribute("custId");
		ITransactionService transervice=new TransactionServiceImpl();
		IAccountService accService=new AccountServiceImpl();
		Customer cust=new Customer();
		cust.setCustomerId(custId);
		
		Set<Account> accounts =accService.getAccountsForCustomer(cust);
		
		//System.out.println(transactions);
		out.println("<html>"
				+ "<head>"
				+ "<title>CapgBanking</title>\r\n" + 
				"<link type=\"text/css\" rel=\"stylesheet\" href=\"./styles/mainStyles.css\">"
				+ "</head>"
				+"<body>"
				+""
				+"<table align=\"center\" border=1>\r\n" + 
						"<tr>\r\n" + 
						"<th>TransactionDate</th>\r\n" + "\t"+
						"<th>FromAccount</th>\r\n" +  "\t"+
						"<th>ToAccount</th>\r\n" + "\t"+
						"<th>Transaction Type</th>\r\n" +  "\t"+
						"<th>AccountType</th>" +  "\t"+
						"<th>Amountt</th></tr>\r\n" + 
						"</tr>"
				);
		
		/* String dob=request.getParameter("fromdate");
		 String[] dates=dob.split("-");
			LocalDate fromdate=LocalDate.of(Integer.parseInt(dates[0]), 
					Integer.parseInt(dates[1]), Integer.parseInt(dates[2]));
		
			 String dob1=request.getParameter("todate");
			 String[] dates1=dob1.split("-");
				LocalDate todate=LocalDate.of(Integer.parseInt(dates[0]), 
						Integer.parseInt(dates[1]), Integer.parseInt(dates[2]));
				List<Transaction> transactions = transervice.getAllTransactions(cust,fromdate,todate);*/
		List<Transaction> transactions = transervice.getAllTransactions(cust);

		    for (Transaction transaction:transactions)
		    {
		    	
		    	Account acc=accService.getAccount(transaction.getFromAccount());
		    	    out.println("<tr><td>"+transaction.getTransactionDate()+"<td>"+transaction.getFromAccount()+"<td>"+transaction.getToAccount()+
		    			"<td>"+transaction.getTransactionType()+"<td>"+acc.getAccountType()+"<td>"+transaction.getAmount()+"</tr>");
		    	
		    }
				out.println("</table><br><table align=\"center\" border=1>"
               
				);
				for(Account acc1: accounts) {
					double curr=0;
					curr=acc1.getOpeningBalance(); 
					  double currs=curr;
				      double currc=curr;
				      double currd=curr;
				      double curfd=curr;
				      out.println("<tr><th>CurrentBalance:</th>\r\n" + 
							    
							"<td>"+acc1.getAccountType()+"</td>\r\n" );
					    
				for(Transaction transaction1:transactions)
				{
				
					//Account acc1=accService.getAccount(transaction1.getFromAccount());
					
					if(acc1.getAccountNo()==transaction1.getFromAccount()) {
					   
					      switch(acc1.getAccountType()) {		
					case SAVINGS:
						if(transaction1.getTransactionType().equals("Debit"))
						{
							currs=currs-transaction1.getAmount();
						}
						else
						{
							currs=currs+transaction1.getAmount();
						}
						curr=currs;
						break;
					case CURRENT:
						if(transaction1.getTransactionType().equals("Debit"))
						{
							currc=currc-transaction1.getAmount();
						}
						else
						{
							currc=currc+transaction1.getAmount();
						}
						curr=currc;
						break;
					case RD:
						if(transaction1.getTransactionType().equals("Debit"))
						{
							currd=currd-transaction1.getAmount();
						}
						else
						{
							currd=currd+transaction1.getAmount();
						}
						curr=currd;
						break;
					case FD:
						if(transaction1.getTransactionType().equals("Debit"))
						{
							curfd=curfd-transaction1.getAmount();
						}
						else
						{
							curfd=curfd+transaction1.getAmount();
						}
						curr=curfd;
						break;
						default:
							System.out.println("hey Invalid enum");
						   break;
						
					
					}
						
						
					}
				}
				out.println("<td>"+acc1.getAccountNo()+"</td>"+"<td>"+curr+"</td></tr>");
				}
				out.println("</table></body>"
		                 + "</html>");
		
	}

}
