package org.capg.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capg.model.Address;
import org.capg.model.Customer;
import org.capg.service.CustomerServiceImpl;
import org.capg.service.ICustomerService;


@WebServlet("/Registration")
public class Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ICustomerService customerService= new CustomerServiceImpl();
		Customer customer=new Customer();
		Address address =new Address();
		
		
		customer.setFirstName(request.getParameter("firstName"));
		customer.setLastName(request.getParameter("lastName"));
		  String dob=request.getParameter("dateOfbirth");
		  //System.out.println(dob);
		  String[] dates=dob.split("-");
			LocalDate date=LocalDate.of(Integer.parseInt(dates[0]), 
					Integer.parseInt(dates[1]), Integer.parseInt(dates[2]));
		   	customer.setDateOfBirth(date);
		customer.setEmailId(request.getParameter("email"));
		customer.setMobile(request.getParameter("mobile"));
	  // if(request.getParameter("custPwd").equals(request.getParameter("confirmcustPwd")))
		 customer.setPassword(request.getParameter("custPwd"));
	   address.setAddressLine1(request.getParameter("addressline1"));
	   address.setAddressLine2(request.getParameter("addressline2"));
	   address.setCity(request.getParameter("city"));
	   address.setState(request.getParameter("state"));
	   address.setPinCode(Integer.parseInt(request.getParameter("pin").toString()));
	   
	  
		   
		
		customer.setAddress(address);
		customerService.createCustomer(customer);
				
		
	}

}
