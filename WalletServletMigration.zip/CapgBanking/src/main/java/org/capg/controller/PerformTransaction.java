package org.capg.controller;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.Transaction;
import org.capg.service.ITransactionService;
import org.capg.service.TransactionServiceImpl;


@WebServlet("/PerformTransaction")
public class PerformTransaction extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ITransactionService transervice=new TransactionServiceImpl();
		Transaction transaction=new Transaction();
		transaction.setTransactionDate(LocalDate.now());
		transaction.setTransactionType(request.getParameter("tranttype"));
		transaction.setAmount(Double.parseDouble(request.getParameter("amount")));
		Account account =new Account();
		int accountNo=Integer.parseInt(request.getParameter("accountNo"));
		account.setAccountNo(accountNo);
		transaction.setFromAccount(accountNo);
		transaction.setToAccount(0);
		transaction.setDescription(request.getParameter("desc"));
		HttpSession session=request.getSession();
		int custId=Integer.parseInt(session.getAttribute("custId").toString());
		Customer customer=new Customer();
		customer.setCustomerId(custId);
		transaction.setCustomerId(custId);
		transervice.createTransaction(transaction);
		
		 response.sendRedirect("TransactionServlet");
		
		}

}
