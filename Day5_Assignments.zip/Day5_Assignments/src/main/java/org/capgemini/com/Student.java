package org.capgemini.com;

public interface Student {

	 void displayGrade();
	 void attendance();
	 
}
