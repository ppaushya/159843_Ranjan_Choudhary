package org.capgemini.com;

public interface TestInterface {
	void division();
	void modules();
	

}
