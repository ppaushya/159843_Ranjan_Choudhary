package org.capgemini.com;

public class MainClass implements Interface1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MainClass m= new MainClass();
		int res=m.getElement();
		System.out.println("Sum is:"+res);

		m.printElement();
		System.out.println("constant in class"+num);


	}

}
