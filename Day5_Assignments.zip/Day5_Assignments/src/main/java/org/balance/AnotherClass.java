package org.balance;
import balance.Account;
public class AnotherClass {

	public static void main(String[] args) {
     Account a= new Account();
     a.displayBalance();
    
	}

}
