package balance;

public class Account {

	int salary=2000;
	public void displayBalance()
	{
		System.out.println("This is the balance "+salary);
	}
	
}
