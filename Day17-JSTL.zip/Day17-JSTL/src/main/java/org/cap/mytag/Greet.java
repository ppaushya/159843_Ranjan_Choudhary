package org.cap.mytag;

import java.io.IOException;
import java.time.LocalTime;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class Greet extends SimpleTagSupport{
	
	private String user;
	private String color;
	

	public String getUser() {
		return user;
	}


	public void setUser(String user) {
		this.user = user;
	}


	public String getColor() {
		return color;
	}


	public void setColor(String color) {
		this.color = color;
	}


	@Override
	public void doTag() throws JspException, IOException {
		JspWriter out=getJspContext().getOut();
		LocalTime time=LocalTime.now();
		
		if(this.user==null)
			user="Capgemini";
		
		out.println("<h3>Good Afternoon!<span style='color:"+this.color+"'>"+this.user+"</span></h3>");
	}
	
	

}
