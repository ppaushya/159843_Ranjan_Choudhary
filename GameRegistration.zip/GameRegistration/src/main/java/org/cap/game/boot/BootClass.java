package org.cap.game.boot;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.cap.game.dao.RegistrationDaoImpl;
import org.cap.game.exception.InvalidAgeException;
import org.cap.game.model.Registration;
import org.cap.game.service.IRegistrationService;
import org.cap.game.service.RegistrationServiceImpl;
import org.cap.game.view.UserInteraction;

public class BootClass {
	final static Logger logger=Logger.getLogger(BootClass.class);
	
	public static void main(String[] args) throws InvalidAgeException {
		Registration registration=new Registration();
		int choice;
		Scanner sc=new Scanner(System.in);
		UserInteraction ui=new UserInteraction();
		IRegistrationService registrationService=new RegistrationServiceImpl();
		while(true)	{
			System.out.println("Make a choice:");
			System.out.println("1. Customer Registration");
			System.out.println("2. Exit");
			
			choice=sc.nextInt();
				
				if(choice==1)
				{
					registration=ui.getRegistrationDetails();
					logger.info("Customer details fetched from DB!");
					registrationService.createRegistration(registration);
					ui.generateAcknowledgement();
					logger.info("Customer added to Registration DB!");
				}
				else if(choice==2)
					System.exit(0);
			}
	}

}
