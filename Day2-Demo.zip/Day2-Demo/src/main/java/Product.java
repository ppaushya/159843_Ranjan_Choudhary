import java.util.Scanner;

public class Product {
	
	String productName;
	int productId, quantity;
	double price,discount,tax;
	
	public void getProductDetails() {
		Scanner s= new Scanner(System.in);
		System.out.println("Enter Product Name");
		productName=s.next();
		System.out.println("Enter Product Id");
		productId=s.nextInt();
		System.out.println("Enter Product Price");
		price=s.nextDouble();
		System.out.println("Enter Product Discount");
		discount=s.nextDouble();
		s.close();
		
	}
	public double calcDiscount() {
		return (discount*price*0.01);
	}
	public double calcTax() {
		int t;
		if(discount>90)
			t=1;
		else if(discount>80)
			t=12;
		else if(discount>70)
			t=20;
		else if(discount>60)
			t=25;
		else t=40;
		return price*t*.01;
	}
	public void calcFinalPrice() {
		double a,b;
		a=calcTax();
		b=calcDiscount();
		System.out.println("Final Price:");
		System.out.println(price+a-b);
	}

	public static void main(String[] args) {
		Product p=new Product();
		p.getProductDetails();
		p.calcFinalPrice();
		// TODO Auto-generated method stub

	}

}
