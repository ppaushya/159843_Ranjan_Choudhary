
public class EvenNum {

	public static void main(String[] args) {
		int num=1,sum=0,n=1,count=0;
		/*while(num<101) {
			if ((num%2)==0) {
				sum+=num;
				System.out.print(num + ",");
				if ((num%10)==0)
					System.out.println("" );
			}
			num++;
			
		}
		System.out.println(sum);
		*/
		while(n<101) {
			if((n%2)==0) {
				System.out.print(n+",");
				
			    count++;
			}
			if (count==5) {
				System.out.println(" ");
				count=0;
			}	
			n++;
		}

	}

}
