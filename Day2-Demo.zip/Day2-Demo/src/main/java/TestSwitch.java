
public class TestSwitch {

	public static void main(String[] args) {
		int num=10;
		char a='c';
		String str="three";
		switch(num)
		{
			case 1:
			case 10:
			case 100:{
				System.out.println("One,");
				break;
			}
			case 2:
				System.out.println("Two,");
				break;
			default: 
				System.out.println("Default,");
			break;	
			
		}
		switch(a)
		{
			case 'a':
			case 'b':
			case 'c':{
				System.out.println("AAAAAAA,");
				break;
			}
			case 'd':
				System.out.println("Twoooooooooo,");
				break;
			default: 
				System.out.println("Defaultttttttttt,");
			break;	
			
		}
		switch(str)
		{
			case "one":
			case "ten":
			case "hundred":{
				System.out.println("1,");
				break;
			}
			case "Two":
				System.out.println("Two,");
				break;
			default: 
				System.out.println("DDDDDefault,");
			break;	
			
		}

	}

}
