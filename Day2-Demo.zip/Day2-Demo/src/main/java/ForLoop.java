public class ForLoop {
	public static void main(String[] args) {
		int count=1,rows=0,sum=1;
		/*for(int i = 5;i>0;i--) {
			for(int j=4;j>0;j--) {
				if(j>=i)
					System.out.print(" ");
				else System.out.print("*");
			}
			System.out.println();
		}*/
		
		
		/*for(int i=0;i<4;i++) {
			for(int j=0;j<=i;j++) {
				System.out.print(count+" ");
				count++;
			}
			System.out.println();
		}*/
		
		
		
	}

}
