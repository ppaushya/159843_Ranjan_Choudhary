import java.util.Scanner;

public class AssignmentDay2 {
	
	
		
	public static void sumD(int num) {
		int sum=0;
		while(num>0) {
			sum=sum +num%10;
			num=num/10;
			
		}
		System.out.println("Sum of Digits:"+sum);
	}
	
	public static void prime() {
		int flag=0;
		System.out.println(1);
		for(int i=3;i<=100;i++) {
			flag=0;
			for (int j=2;j<i;j++) {
				if(i%j==0)
					flag=flag+1;
			}
			if (flag==0) {
				System.out.println(i);
				}
			
		}
	}
	public static void arms() {
		int sum=0,num,g;
		for(int i=1;i<=1000;i++) {
			sum=0;
			num=i;
		while(num>0) {
			g=num%10;
			sum=sum + (g*g*g);
			num=num/10;
			
		}
		if (sum==i) {
			System.out.println(i);}
		//System.out.println(i);
		}
	}
	
	public static void strPtr(String s) {
		int l=s.length();
		for(int i=0;i<l;i++) {
			for(int j=0;j<=i;j++) {
				System.out.print(s.charAt(j));
			}
			System.out.println();
		}
		
	}

	public static void main(String[] args) {
		//Q.2
		/*int a=0;
		System.out.println("Enter Digit:");
		Scanner scan=new Scanner(System.in);
		a=scan.nextInt();
		sumD(a);
		scan.close();*/
		//Q.3-prime();
		//Q.4--arms();
		//Q.5
		/*String s;
		System.out.println("Enter String:");
		Scanner scan=new Scanner(System.in);
		s=scan.next();
		strPtr(s);
		scan.close();*/
		
        //Q.1 Number Pattern
		int i=1,j,temp,k,count=0;
		
		while(i<=20)
		{
			temp=i+1;
			for(j=i;j<i+6 && j<=20;j=j+2)
			{
				System.out.print(j+" ");
				count++;
					
			}
			
			if(count!=3)
			{
				System.exit(0);
			}
			else
			{
				count=0;
			}
		
			i=j;
			for(k=temp;k<temp+6 && k<=20;k=k+2)
			{
				System.out.print(k+" ");
				count++;
			}
			if(count!=3)
			{
				System.exit(0);
			}
			else
			{
				count=0;
			}
		}

	}

}
