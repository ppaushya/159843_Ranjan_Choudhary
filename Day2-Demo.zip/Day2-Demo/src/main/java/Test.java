
public class Test {
	
	public void testIf(int num) {
		if(num>0) {
			System.out.println("Positive");
			if(num%2==0)
				System.out.println("Even");
			else
				System.out.println("Odd");
		}	
		else if(num<0)
			System.out.println("Negative");
		else 
			System.out.println("Zero");
	}

	public static void main(String[] args) {
		Test c1= new Test();
		c1.testIf(25);
		// TODO Auto-generated method stub

	}

}
