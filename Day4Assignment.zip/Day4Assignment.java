import java.util.Scanner;

public class Day4Assignment {
	
	public void firstFactorial(int num) {
		double fact=1;
		for(int i=1;i<=num;i++) {
			fact=fact*i;
		}
		System.out.println(fact);
	}
	
	public void letterChanges(String str) {
		char[] ch = new char[str.length()];
		for(int i=0;i<str.length();i++) {
			ch[i]=str.charAt(i);
			//ch[i]=(char) (ch[i]+1);
			if (ch[i]=='z')
				ch[i]='a';
			else ch[i]=(char) (ch[i]+1);
			if(ch[i]=='a'||ch[i]=='e'||ch[i]=='i'||ch[i]=='o'||ch[i]=='u')
				ch[i]=(char) (ch[i]-32);
		
		}
		for(int i=0;i<str.length();i++) {
			System.out.print(ch[i]);
		}
		
	}
	
	public void reverseOrder(String str) {
		char[] ch = new char[str.length()];
		char[] ch1 = new char[str.length()];
		for(int i=0,j=str.length()-1;i<str.length();i++,j--) {
			ch[i]=str.charAt(i);
			ch1[j]=ch[i];
		}
		for(int i=0;i<str.length();i++) {
			System.out.print(ch1[i]);
		}
	}
	
	public void primeFraction(int num) {
		for(int i=2;i<num;i++) {
			while(num%i==0) {
				System.out.println(i+ " ");
				num=num/i;
			}
		}
		if(num>2)
			System.out.println(num);
	}
	
	public void AlphabetSoup(String s) {
		char[] ch = new char[s.length()];
		for(int i=0;i<s.length();i++) {
			ch[i]=s.charAt(i);	
		}
		char temp;
		for (int i=0;i<s.length();i++) {
			for(int j=0;j<s.length();j++) {
				if(ch[i]<ch[j]) {
					temp=ch[i];
					ch[i]=ch[j];
					ch[j]=temp;
				}		
			}		
		}
		for(int i=0;i<s.length();i++)
			System.out.print(ch[i]);
	}
	
	public void letterCapitalize(String s) {
		char[] ch = new char[s.length()];
		for(int i=0;i<s.length();i++) {
			ch[i]=s.charAt(i);
		}
		ch[0]=(char) (ch[0]-32);
		for(int i=0;i<s.length();i++) {
			if(ch[i]==' ') {
				//System.out.println("Space");
				ch[i+1]=(char) (ch[i+1]-32);
			}
			//else System.out.println("No space");
		}
		for(int i=0;i<s.length();i++) {
			System.out.print(ch[i]);
		}
		
	}
	public void anagram(String strf,String strt) {
		String str1=strf.toLowerCase();
		String str2=strt.toLowerCase();
		//System.out.println(str);
		int flag=0;
		char[] ch1 = new char[str1.length()];
		for(int i=0;i<str1.length();i++) {
			ch1[i]=str1.charAt(i);	
		}
		char temp1;
		for (int i=0;i<str1.length();i++) {
			for(int j=0;j<str1.length();j++) {
				if(ch1[i]<ch1[j]) {
					temp1=ch1[i];
					ch1[i]=ch1[j];
					ch1[j]=temp1;
				}		
			}		
		}
		char[] ch2 = new char[str2.length()];
		for(int i=0;i<str2.length();i++) {
			ch2[i]=str2.charAt(i);	
		}
		char temp2;
		for (int i=0;i<str2.length();i++) {
			for(int j=0;j<str2.length();j++) {
				if(ch2[i]<ch2[j]) {
					temp2=ch2[i];
					ch2[i]=ch2[j];
					ch2[j]=temp2;
				}		
			}		
		}
		for(int i=0;i<str1.length();i++) {
			if(ch1[i]!=ch2[i]) {
				flag=1;
				System.out.println("Strings are not Anagram");
				break;
			}
		}
		if (flag==0)
			System.out.print("Strings are Anagram");
	}
	
	public String longestWord(String str) {
		
		String s="",maxWord="";
		int maxlen=0,p=0;
		for(int i=0;i<str.length();i++)
		{
            if(str.charAt(i)!=' ')
		{
		s=s+str.charAt(i);
		}
		else
		{
		p=s.length();
		if((int) p>maxlen)
		{
		maxlen=p;
		maxWord=s;
		}
		s="";
		}
		}
		return maxWord;
		
	}

	public static void main(String[] args) {
		Day4Assignment obj=new Day4Assignment();
		Scanner s=new Scanner(System.in);
		char d=' ';
		int a=d;
		//System.out.println(a);
		//System.out.println("Enter the number");
		//int n=s.nextInt();
		//obj.primeFraction(n);
		System.out.println("Enter the String 1");
		String str=s.nextLine();
		//System.out.println("Enter the String 2");
		//String str1=s.nextLine();
		//System.out.println(str.length());
		//obj.AlphabetSoup(str);
		//obj.letterCapitalize(str);
		//obj.letterChanges(str);
		//obj.reverseOrder(str);
		//obj.firstFactorial(n);
		//obj.anagram(str, str1);
		//obj.longestWord(str);
		String st=obj.longestWord(str);
		System.out.println(st);

	}

}
