package paymentDetails;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {

	private WebDriver driver;
	private WebElement element;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\ranjacho\\Downloads\\chromedriver.exe");
		driver= new ChromeDriver();
	}
	
	@Given("^Open Payment Details page$")
	public void open_Payment_Details_page() throws Throwable {
		driver.get("file:///C:/Users/ranjacho/Downloads/Conferencebooking/PaymentDetails.html");
		String str=driver.findElement(By.tagName("h4")).getText();
		if(!driver.getTitle().equals("Payment Details")|| !str.equals("Step 2: Payment Details")) {
			driver.quit();
		}
	}

	@Given("^debit card details$")
	public void debit_card_details() throws Throwable {
		driver.findElement(By.name("txtFN")).sendKeys("Ranjan Choudhary");
		driver.findElement(By.name("debit")).sendKeys("1452-3654-1256-4589");
		driver.findElement(By.name("cvv")).sendKeys("982");
		driver.findElement(By.name("month")).sendKeys("05");
		driver.findElement(By.name("year")).sendKeys("2025");
	}

	@When("^Clicked Make Payment$")
	public void clicked_Make_Payment() throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"btnPayment\"]")).click();
	}

	@Then("^Show Registration Successfull$")
	public void show_Registration_Successfull() throws Throwable {
	    
	}


}
