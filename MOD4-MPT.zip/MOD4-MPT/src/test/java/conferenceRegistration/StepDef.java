package conferenceRegistration;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	
	private WebDriver driver;
	private WebElement element;
	private String message;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\ranjacho\\Downloads\\chromedriver.exe");
		driver= new ChromeDriver();
	}

	@Given("^Open Conference Registration page$")
	public void open_Conference_Registration_page() throws Throwable {
		driver.get("file:///C:/Users/ranjacho/Downloads/Conferencebooking/ConferenceRegistartion.html");
		String str=driver.findElement(By.tagName("h4")).getText();
		if(!driver.getTitle().equals("Conference Registartion")|| !str.equals("Step 1: Personal Details")) {
			driver.quit();
		}
		Thread.sleep(3000);
	}

	@Given("^provide registration details$")
	public void provide_registration_details() throws Throwable {
		 
					

					//first name
					element = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
					element.click();
					message = driver.switchTo().alert().getText();
					assertEquals(message, "Please fill the First Name");
					Thread.sleep(1500);
					driver.switchTo().alert().accept();
					element = driver.findElement(By.xpath("//*[@id=\"txtFirstName\"]"));
					System.out.println((element.isDisplayed()));
					element.sendKeys("Ranjan");

					// 6. last name
					element = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
					element.click();
					message = driver.switchTo().alert().getText();
					assertEquals(message, "Please fill the Last Name");
					Thread.sleep(1500);
					driver.switchTo().alert().accept();
					element = driver.findElement(By.xpath("//*[@id=\"txtLastName\"]"));
					System.out.println((element.isDisplayed()));
					element.sendKeys("Choudhary");

					// 7. email
					element = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
					element.click();
					message = driver.switchTo().alert().getText();
					assertEquals(message, "Please fill the Email");
					Thread.sleep(1500);
					driver.switchTo().alert().accept();
					element = driver.findElement(By.xpath("//*[@id=\"txtEmail\"]"));
					System.out.println((element.isDisplayed()));
					element.sendKeys("ran@gmail.com");

					// 8. contact no
					element = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
					element.click();
					message = driver.switchTo().alert().getText();
					assertEquals(message, "Please fill the Contact No.");
					Thread.sleep(1500);
					driver.switchTo().alert().accept();
					element = driver.findElement(By.xpath("//*[@id=\"txtPhone\"]"));
					System.out.println((element.isDisplayed()));
					element.sendKeys("9808182323");


					// 9. number of people
					element = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a"));
					element.click();
					message = driver.switchTo().alert().getText();
					assertEquals(message, "Please fill the Number of people attending");
					Thread.sleep(1500);
					driver.switchTo().alert().accept();
					element = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[5]/td[2]/select/option[2]"));
					System.out.println((element.isDisplayed()));
					element.click();

					// 10. street address
					element = driver.findElement(By.xpath("//*[@id=\"txtAddress1\"]"));
					System.out.println((element.isDisplayed()));
					element.sendKeys("OMR");
					element = driver.findElement(By.xpath("//*[@id=\"txtAddress2\"]"));
					System.out.println((element.isDisplayed()));
					element.sendKeys("ECR road");
					Thread.sleep(1500);

					// 11. city
					element = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[9]/td[2]/select/option[4]"));
					System.out.println((element.isDisplayed()));
					element.click();
					Thread.sleep(1500);

					// 12. state
					element = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[10]/td[2]/select/option[4]"));
					System.out.println((element.isDisplayed()));
					element.click();
					Thread.sleep(1500);

					// 13. Conference full-Access(member)
					element = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[12]/td[2]/input"));
					System.out.println((element.isDisplayed()));
					element.click();
					Thread.sleep(1500);

					// 14. Conference full-Access(non-member)
					element = driver.findElement(By.xpath("/html/body/form/table/tbody/tr[13]/td[2]/input"));
					System.out.println((element.isDisplayed()));
					element.click();
					Thread.sleep(1500);
			 
	}

	@When("^Clicked Next$")
	public void clicked_Next() throws Throwable {
		driver.findElement(By.xpath("/html/body/form/table/tbody/tr[14]/td/a")).click();
		Thread.sleep(1500);
	}

	@Then("^Navigate to Payment Details Page$")
	public void navigate_to_Payment_Details_Page() throws Throwable {
		driver.switchTo().alert().accept();
		Thread.sleep(1500);
		
	}

	@Given("^Open Payment Details page$")
	public void open_Payment_Details_page() throws Throwable {
		driver.get("file:///C:/Users/ranjacho/Downloads/Conferencebooking/PaymentDetails.html");
		String str=driver.findElement(By.tagName("h4")).getText();
		if(!driver.getTitle().equals("Payment Details")|| !str.equals("Step 2: Payment Details")) {
			driver.quit();
		}
	}

	@Given("^debit card details$")
	public void debit_card_details() throws Throwable {
				// last name
				element = driver.findElement(By.xpath("//*[@id=\"txtCardholderName\"]"));
				System.out.println((element.isDisplayed()));
				element.sendKeys("Ranjan Choudhary");
				Thread.sleep(1500);

				// card number
				element = driver.findElement(By.xpath("//*[@id=\"txtDebit\"]"));
				System.out.println((element.isDisplayed()));
				element.sendKeys("1256-7856-8562-1254");
				Thread.sleep(1500);

				//  CVV
				element = driver.findElement(By.xpath("//*[@id=\"txtCvv\"]"));
				System.out.println((element.isDisplayed()));
				element.sendKeys("125");
				Thread.sleep(1500);

				// Expiration Month
				element = driver.findElement(By.xpath("//*[@id=\"txtMonth\"]"));
				System.out.println((element.isDisplayed()));
				element.sendKeys("05");
				Thread.sleep(1500);

				//  Expiration Year
				element = driver.findElement(By.xpath("//*[@id=\"txtYear\"]"));
				System.out.println((element.isDisplayed()));
				element.sendKeys("2025");
				Thread.sleep(1500);

		
	}

	@When("^Clicked Make Payment$")
	public void clicked_Make_Payment() throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"btnPayment\"]")).click();
		Thread.sleep(1500);
	}

	@Then("^Show Registration Successfull$")
	public void show_Registration_Successfull() throws Throwable {
		Thread.sleep(1500); 
	}


}
