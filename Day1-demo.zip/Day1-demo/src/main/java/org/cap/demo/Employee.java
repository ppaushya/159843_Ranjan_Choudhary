package org.cap.demo;

import java.util.Scanner;

public class Employee {
	
	int empId,age;
	String empName,address;
	boolean isPermanent;
	String gender;
	
	public void getEmployee() {
		
		Scanner scanner= new Scanner(System.in);
		System.out.println("Enter EmployeeId,Employee Name, Age, Permanent,gender,Address");
		empId=scanner.nextInt();
		empName=scanner.next();
		age=scanner.nextInt();
		isPermanent=scanner.nextBoolean();
		gender=scanner.next();
		address=scanner.next();
		
		scanner.close();
	}
	
	public void printEmployee() {
		
		System.out.println("Employee Id:" + empId);
		System.out.println("Employee Name:" + empName);
		System.out.println("Employee Age:" + age);
		System.out.println("Employee Status:" + isPermanent);
		System.out.println("Employee Gender:" + gender);
		System.out.println("Employee Address:" + address);
	}

	public static void main(String[] args) {
		
		Employee e = new Employee();
		e.getEmployee();
		e.printEmployee();
		// TODO Auto-generated method stub

	}

}
