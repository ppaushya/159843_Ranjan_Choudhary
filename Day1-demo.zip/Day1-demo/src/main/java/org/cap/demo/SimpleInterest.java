package org.cap.demo;

import java.util.Scanner;

public class SimpleInterest {
	
	double principle;
	float rateOfInterest;
	float years;
	
	public void getData() {
		//principle=4000;
		//rateOfInterest=0.0665f;
		//years=3.3f;
		
		Scanner scanner= new Scanner(System.in);
		System.out.println("Enter Principle");
		principle=scanner.nextDouble();
		
		System.out.println("Enter Years");
		years=scanner.nextFloat();
		
		System.out.println("Enter Rate of Interest");
		rateOfInterest=scanner.nextFloat();
		
		scanner.close();
		
	}
	
	public double calculateInterest() {
		return principle*years*rateOfInterest;
		
	}

	public static void main(String[] args) {
		
		SimpleInterest s1= new SimpleInterest();
		s1.getData();
		double simpleinter=s1.calculateInterest();
		System.out.println("Simple Interest is:" + simpleinter);
		// TODO Auto-generated method stub

	}

}
