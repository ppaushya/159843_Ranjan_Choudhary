package org.cap.demo;

import java.util.Scanner;

public class Student {
	
	String name;
	int m1,m2,m3;
	
	public void getStudent() {
		
		Scanner s= new Scanner(System.in);
		System.out.println("Enter Name");
		name=s.next();
		System.out.println("Enter Marks");
		m1=s.nextInt();
		m2=s.nextInt();
		m3=s.nextInt();
		s.close();
		
	}
	
	public int findScore() {
		return m1+m2+m3;
	}
	
	public double findAvg() {
		return (m1+m2+m3)/3;
	}
	public void printStudent() {
		double a,b;
		a=findScore();
		b=findAvg();
		System.out.println("Student Name:" + name);
		System.out.println("Student Marks:" + m1 + m2 + m3);
		System.out.println("Score:" + a);
		System.out.println("Avg:" + b);
		
	}

	public static void main(String[] args) {
		
		Student s = new Student();
		s.getStudent();
		s.printStudent();
		
		// TODO Auto-generated method stub

	}

}
