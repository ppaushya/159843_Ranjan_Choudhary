package org.capg.dao;

import java.util.List;

import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.Customer;
public interface ICustomerDao {
	
	public List<Customer> getAllCustomers();
	public void createCustomer(Customer customer);
	public Customer isFound(int customerId);
	public void setAccountDetails(Customer customer,Account account);

}
