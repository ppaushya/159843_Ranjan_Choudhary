var myFun=function(){
	console.log("Hello! Good Afternoon")
	
}
myFun()

var emp={
		empId : 1001 ,
		firstName:'Tom',
		lastName:'Jerry',
		salary:2000
		
}

console.log(emp.empId)
console.log(emp)
alert('empId' in emp)
for(key in emp){
	console.log(key+ '-'+emp[key])
}

function createCustomer(custId,custName,address,mobile)
{
	this.custId=custId
	this.custName=custName
	this.address=address
	this.mobile=mobile
	
	this.setCustId=function(custId){
		this.custId=custId;
	}
	this.getCustId=function(){
		return this.custId
	}
	}

var customer=new createCustomer(101,'Gon','Tekken 3',987654);

console.log(customer.custId)
console.log(customer.custName)




















