package org.cap.object.demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ObjectRead {

	public static void main(String[] args) {


		File file=new File("D:\\Product.dat");
		//UserInteraction user=new UserInteraction();
		
		try(FileInputStream in=new FileInputStream(file);
				ObjectInputStream inputStream=new ObjectInputStream(in);) {
			Product[] product=new Product[5];
			
			for(int i=0;i<5;i++) {
				 product[i]=(Product)inputStream.readObject();
				 System.out.println(product[i]);
			}
				 
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
