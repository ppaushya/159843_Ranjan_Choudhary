package org.cap.object.demo;

import java.time.LocalDate;
import java.util.Scanner;

public class UserInteraction {
	Scanner scanner=new Scanner(System.in);
	
	public Product getProduct() {
		Product product=new Product();
		
		System.out.println("Enter Product Id");
		product.setProductId(scanner.nextInt());
		System.out.println("Enter Product Name");
		product.setProductName(scanner.next());
		System.out.println("Enter Product Quantity");
		product.setQuantity(scanner.nextInt());
		System.out.println("Enter Product Price");
		product.setPrice(scanner.nextDouble());
		System.out.println("Enter Product Expiry Date");
		product.setExpiryDate(LocalDate.now());
		
		return product;
	}

}
