package org.cap.object.demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ObjectWrite {

	public static void main(String[] args) {
		
		File file=new File("D:\\Product.dat");
		UserInteraction user=new UserInteraction();
		
		try(FileOutputStream out=new FileOutputStream(file);
				ObjectOutputStream outputStream=new ObjectOutputStream(out);) {
			Product product=new Product();
			for(int i=0;i<5;i++) {
				 product=user.getProduct();
				 outputStream.writeObject(product);
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		

	}

}
