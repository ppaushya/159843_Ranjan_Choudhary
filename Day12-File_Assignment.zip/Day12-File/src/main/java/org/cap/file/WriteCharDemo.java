package org.cap.file;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class WriteCharDemo {

	public static void main(String[] args) {


		File file=new File("D:\\WriteDemo1.txt");
		int ch=0;
		String greetings="Good Afternoon";
		try(FileWriter writer=new FileWriter(file)) {
//			char[] ch=greetings.toCharArray();
//			
//			for(char c:ch)
//				writer.write(c);
			writer.write(greetings);
			
		}catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try(FileReader reader=new FileReader(file)) {
	
	
			char[] rev=new char[100];
			int i=0;
	        while(ch!='\0') {
	        	ch=reader.read();
				System.out.print((char)ch);
				
					 rev[i]=(char) ch;
				i++;
			} 
			
	
		
				
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
