package org.cap.file;

import java.io.File;
import java.io.IOException;

public class FileDemo {

	public static void main(String[] args) {


		File file=new File("D:\\\\MyFileDemo.txt");
		
		//file.delete();
		
		if(file.isFile()) {
			if (file.exists()) {
				System.out.println("Readable "+ file.canRead());
				System.out.println("Writable "+ file.canWrite());
				System.out.println("Executale "+ file.canExecute());
				System.out.println("Readable "+ file.getAbsolutePath());
			}else System.out.println("File not Found");
	
		}else if(file.isDirectory()) {
			String[] names=file.list();
			for(String name:names)
				System.out.println(name);
			
		}else {System.out.println("No file/directory exists");
		       try {
				file.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		       }
		
		System.out.println("Free Space "+file.getFreeSpace());
		System.out.println("Total Space "+file.getTotalSpace());
		System.out.println("Used Space "+file.getUsableSpace());

	}

}
