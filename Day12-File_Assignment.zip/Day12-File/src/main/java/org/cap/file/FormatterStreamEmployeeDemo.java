package org.cap.file;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class FormatterStreamEmployeeDemo {


	
	public static void main(String[] args) {


		int empId;
		String empName;
		boolean isPermanent;
		char gender;
		double salary;
		
		
		File file=new File("D:\\FormatterEmployee.txt");
		Scanner scanner=new Scanner(System.in);
		
		try(FileOutputStream out=new FileOutputStream(file);
				DataOutputStream outputStream=new DataOutputStream(out);){
			
			for(int i=0;i<1;i++) {
				System.out.println("Enter Employee Id");
				empId=scanner.nextInt();
				outputStream.writeInt(empId);
				
				System.out.println("Enter Employee Status");
				isPermanent=scanner.nextBoolean();
				outputStream.writeBoolean(isPermanent);
				System.out.println("Enter Employee Gender");
				gender=scanner.next().charAt(0);
				outputStream.writeChar(gender);
				System.out.println("Enter Employee Salary");
				salary=scanner.nextDouble();
				outputStream.writeDouble(salary);
				System.out.println("Enter Employee Name");
				empName=scanner.next();
				outputStream.write(empName.getBytes());
				
			}
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try(FileInputStream in=new FileInputStream(file);
				DataInputStream inputStream=new DataInputStream(in);){
			
			for(int i=0;i<1;i++) {
				int id=inputStream.readInt();
				
				
				boolean perm=inputStream.readBoolean();
				char gen=inputStream.readChar();
				double sal=inputStream.readDouble();
				String name=inputStream.readLine();
				System.out.println(id+name+perm+gen+sal);
				
				
			}
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
