package org.cap.file;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReadCharFile {

	public static void main(String[] args) {


		File file=new File("D:\\MyFileDemo.txt");
		int ch;
		
		try(FileReader reader=new FileReader(file)) {
			
			do {
				ch=reader.read();
				System.out.print((char)ch);
			}while(ch!=0);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
